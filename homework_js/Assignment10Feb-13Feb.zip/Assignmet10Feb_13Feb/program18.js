let no_Pair=4


let pairs_OfNum={

}
for( let i=1;i<=no_Pair;i++)
{
   document.write (`${i}:${no_Pair},`)
}
//console.log(arr)