
 let numb=12

      for(let i=1;i<=12;i++)
      {
        if(numb%i==0)
        {
            console.log("",i)
        }

      }