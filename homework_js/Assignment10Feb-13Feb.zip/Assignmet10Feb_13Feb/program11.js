let arr="Dreamer infotech"  //0,2,4,6

for(let i=0;i<arr.length;i++)
{
    if(i%2==0)
    {
        document.write(arr[i])
    }
}

