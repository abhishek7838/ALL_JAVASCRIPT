let str=  "abhishek"//prompt("enter a string for check that character exists")
let ch='q'
   
for(let i=0;i<str.length;i++)
{
    if(str[i]==ch)
    {
        console.log("exists")
        break
    }
    
   
}
