
for(let i=1;i<=20;i++)
{
    if(i%2==0)
    {
        console.log("it is even number",i)
    }
    else
    {
        console.log("it is odd Number",i)
    }
}