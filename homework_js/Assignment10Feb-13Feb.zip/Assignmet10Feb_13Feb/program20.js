let start_Num=parseInt(prompt("enter start num"))
let ent_Num=parseInt(prompt("enter start num"))

for(let i=start_Num;i<=ent_Num;i++)
{
    document.write(`${i*i}<br>`)
}